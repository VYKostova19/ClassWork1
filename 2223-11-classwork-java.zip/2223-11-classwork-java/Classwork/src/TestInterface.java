public interface TestInterface {
    void test();
}