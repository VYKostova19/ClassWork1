public class Bicycle
{
    int gear = 5;

    void breaking()
    {
        System.out.println("stop");
    }
}
