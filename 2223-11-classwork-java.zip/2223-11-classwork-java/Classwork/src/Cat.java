public class Cat extends Mammal {
    @Override
    public void test() {
        System.out.println("testing...");
    }
    @Override
    public void walk() {
        System.out.println("walking...");
    }
}