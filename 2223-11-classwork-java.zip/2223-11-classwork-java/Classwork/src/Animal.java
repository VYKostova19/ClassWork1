public interface Animal extends TestInterface {
    void eat();

}